#include "mod/mod.h"
#include <iostream>

void hello(const std::string &msg) {
	std::cout << "Hello, " << msg << "!" << std::endl;
}
