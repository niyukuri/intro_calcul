#include "main.h"

int main() {
	hello("world");
}
